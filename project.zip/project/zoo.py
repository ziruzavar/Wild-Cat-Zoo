
class Zoo:
    def __init__(self,name, budget, animal_capacity, workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []

    def add_animal(self, animal, price):
        if self.__budget < price:
            return "Not enough budget"
        elif self.__animal_capacity <= len(self.animals):
            return "Not enough space for animal"
        self.animals.append(animal)
        self.__budget -= price
        return f"{animal.name} the {type(animal).__name__} added to the zoo"

    def hire_worker(self, worker):
        if len(self.workers) >= self.__workers_capacity:
            return "Not enough space for worker"
        self.workers.append(worker)
        return f"{worker.name} the {type(worker).__name__} hired successfully"

    def fire_worker(self, worker_name):
        worker_ll = [i for i in self.workers if i.name == worker_name]
        if worker_ll:
            worker = worker_ll[0]
            self.workers.remove(worker)
            return f"{worker_name} fired successfully"
        return f"There is no {worker_name} in the zoo"

    def pay_workers(self):
        pay_amount = sum([i.salary for i in self.workers])
        if self.__budget >= pay_amount:
            self.__budget -= pay_amount
            return f"You payed your workers. They are happy. Budget left: {self.__budget}"
        return "You have no budget to pay your workers. They are unhappy"

    def tend_animals(self):
        pay_amount = sum([i.get_needs() for i in self.animals])
        if self.__budget >= pay_amount:
            self.__budget -= pay_amount
            return f"You tended all the animals. They are happy. Budget left: {self.__budget}"
        return "You have no budget to tend the animals. They are unhappy."

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        lions = [l for l in self.animals if type(l) == Lion]
        tigers = [t for t in self.animals if type(t) == Tiger]
        cheetahs = [c for c in self.animals if type(c) == Cheetah]
        result = f"You have {len(self.animals)} animals\n"
        result += f"----- {len(lions)} Lions:\n"
        for l in lions:
            result += f"{l}"+"\n"
        result += f"----- {len(tigers)} Tigers:\n"
        for t in tigers:
            result += f"{t}"+"\n"
        result += f"----- {len(cheetahs)} Cheetahs:\n"
        for c in cheetahs:
            result += f"{c}"+"\n"
        return result

    def workers_status(self):
        keepers = [l for l in self.workers if type(l) == Keeper]
        caretakers = [t for t in self.workers if type(t) == Caretaker]
        vets = [c for c in self.workers if type(c) == Vet]
        result = f"You have {len(self.workers)} workers\n"
        result += f"----- {len(keepers)} Keepers:\n"
        for l in keepers:
            result += f"{l}"+"\n"
        result += f"----- {len(caretakers)} Caretakers:\n"
        for t in caretakers:
            result += f"{t}"+"\n"
        result += f"----- {len(vets)} Vets:\n"
        for c in vets:
            result += f"{c}"+"\n"
        return result
